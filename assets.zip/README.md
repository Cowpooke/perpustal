Perpustal

whats working? : <br>
-login/register <br>
-view peminjaman with automatic penalty <br>
-search function <br>

work in progress : <br>
-book management by admin <br>
-sql injection protection <br>
-ui <br>
